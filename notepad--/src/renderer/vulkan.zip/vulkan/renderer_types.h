#pragma once

#include "math/math_types.h"

struct vulkan_context;

typedef struct renderer_state {
    struct vulkan_context* context;
} renderer_state;
