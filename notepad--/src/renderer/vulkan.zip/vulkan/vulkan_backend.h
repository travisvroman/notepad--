#pragma once

#include "renderer_types.h"
//
#include "vulkan_types.h"

b8 vulkan_renderer_intialize(renderer_state* renderer, vulkan_renderer_config config);
void vulkan_renderer_shutdown(renderer_state* renderer);
